import os
import math
from numpy import *
import cv2
import time
from functools import wraps
from sklearn.preprocessing import normalize


class Multi_class(object):
    # R: the radius, P: the number of sampling points, type: original LBP or circular LBP operator
    # uniform: uniform patterns, devided into w_num * h_num regions
    # overlap_ratio: the ratio of overlapping regions
    def __init__(self, R, P, type, uniform, w_num, h_num, overlap_ratio, isgradiented):
        self.Width = 168
        self.Height = 192
        self.Image_Num = 0
        self.Radius = R
        self.Points = P
        self.lbp_type = type
        self.uniform = uniform
        self.region_class = len(w_num)
        self.w_num = w_num
        self.h_num = h_num
        self.LBPoperator = 0
        self.Histograms = 0
        # self.weight = 0
        # self.isweighted = 0
        self.ids = 0
        self.overlap_ratio = overlap_ratio
        self.gradients = 0
        self.gamma = 0.15
        self.parameter = 0
        self.isgradiented = isgradiented
        self.region_num = 0
        for i in range(self.region_class):
            self.region_num += self.w_num[i]+self.h_num[i]
        if (self.overlap_ratio > 0):
            region_width = self.Width / self.w_num
            region_height = self.Height / self.h_num
            self.overlap_size = int(region_width * self.overlap_ratio)
            print('Overlap_size: %d' % self.overlap_size)
            self.region_w_num = 1 + math.ceil((self.Width - region_width) / (region_width - self.overlap_size))
            self.region_h_num = 1 + math.ceil((self.Height - region_height) / (region_height - self.overlap_size))
        if (self.uniform == 1):
            self.Patterns = self.Points * (self.Points - 1) + 3
            # P*(P-1) for patterns with two transitions,
            # 2 bins for patterns with zero transitions,
            # 1 bin for all miscellaneous patterns
        else:
            self.Patterns = 2 ** self.Points

    # Used for calculating consumed time
    def fn_timer(function):
        @wraps(function)
        def function_timer(*args, **kwargs):
            t0 = time.time()
            result = function(*args, **kwargs)
            t1 = time.time()
            print("Running %s: %s seconds" % (function.__name__, str(around(t1 - t0, decimals=2))))
            return result

        return function_timer

    # Load all image
    def loadImages(self, mypath):
        FaceMat = mat(zeros((self.Image_Num,
                             self.Width * self.Height)))
        j = 0
        for m in os.listdir(mypath):
            if (len(m) == 24):
                try:
                    img = cv2.imread(mypath + m, 0)
                    self.ids[j] = int(m[5:7])
                    self.gradients[:, j] = self.cal_Gradient(mat(img))
                    # img = self.gamma_correction(img, self.gamma)
                    # img = cv2.GaussianBlur(img, (3, 3), 0)
                    # img = cv2.equalizeHist(img)
                    FaceMat[j, :] = mat(img).flatten()
                    j = j + 1
                except:
                    print('Load %s failed' % m)
        print('Successfully loaded %s images' % j)
        return FaceMat  # Rotate the binary string and obtain a minimal binary number for each pattern

    def gamma_correction(self, img, correction):
        img = img / 255.0
        img = cv2.pow(img, correction)
        return uint8(img * 255)

    # Start from the end of the binary string, remove all '0' at the end and place them in the begining.
    def minBinary(self, pixel):
        length = len(pixel)
        last = length - 1
        result = inf
        for i in range(length):
            p = pixel[last]
            pixel = p + pixel[:last]
            temp = int(pixel, base=2)
            if (temp < result):
                result = temp
        return result

    # Main component of LBP
    def LBP(self, FaceMat):
        R = self.Radius
        # The offset of 3*3 neighbors
        if (self.lbp_type == 1):
            Neighbor_x = [-1, 0, 1, 1, 1, 0, -1, -1]
            Neighbor_y = [-1, -1, -1, 0, 1, 1, 1, 0]
        else:
            pi = math.pi
        LBPoperator = mat(zeros(shape(FaceMat)))
        for i in range(shape(FaceMat)[1]):  # obtain the number of images
            face = FaceMat[:, i].reshape(self.Height, self.Width)  # Height represents the number of row
            H, W = shape(face)
            tempface = mat(zeros((H, W)))
            for x in range(R, H - R):
                for y in range(R, W - R):
                    repixel = ''
                    pixel = int(face[x, y])
                    # Original LBP algorithm, 3*3
                    if (self.lbp_type == 1):
                        for p in range(8):
                            xp = x + Neighbor_x[p]
                            yp = y + Neighbor_y[p]
                            if int(face[xp, yp]) > pixel:
                                repixel += '1'
                            else:
                                repixel += '0'
                    # Utilize circular regions, with changeable radius and number of points
                    else:
                        for p in [3, 4, 5, 6, 7, 0, 1, 2]:
                            p = float(p)
                            xp = x + R * cos(2 * pi * (p / self.Points))
                            yp = y - R * sin(2 * pi * (p / self.Points))
                            neighbor_pixel = self.bilinear_interpolation(face, xp, yp)
                            if neighbor_pixel > pixel:
                                repixel += '1'
                            else:
                                repixel += '0'
                                # Obtain the minimal binary string for each pattern
                                # tempface[x, y] = minBinary(repixel)
                    if (self.uniform == 1):
                        U = self.transition_number(repixel)
                        if U <= 2:
                            tempface[x, y] = int(repixel, base=2)
                        else:
                            tempface[x, y] = self.Points + 1
                    else:
                        tempface[x, y] = int(repixel, base=2)
            LBPoperator[:, i] = tempface.flatten().T
        return LBPoperator

    # Utilize Sobel operator calculate image gradients.
    # THe gradient will be used as weight for each pixel
    def cal_Gradient(self, face):
        x64 = cv2.Sobel(face, cv2.CV_64F, 1, 0, ksize=5)
        y64 = cv2.Sobel(face, cv2.CV_64F, 0, 1, ksize=5)
        sobelx = uint8(absolute(x64))
        sobely = uint8(absolute(y64))
        res = cv2.addWeighted(sobelx, 0.5, sobely, 0.5, 0)
        row_sums = res.sum(axis=1)
        res = around(res / row_sums[:, newaxis], decimals=4)
        if self.parameter != 0:
            H, W = shape(res)
            for i in range(H):
                for j in range(W):
                    # res[i, j] = around(math.log(100 * res[i, j] + 1), decimals=4)
                    res[i, j] = around(math.exp(self.parameter * res[i, j]) - 1, decimals=4)

        res = res.flatten().T.reshape(self.Width * self.Height, 1)
        return res

    # Calculate the number of transitions in the binary pattern and judge whether it is a uniform pattern
    def transition_number(self, pattern):
        length = len(pattern)
        count = abs(int(pattern[length - 1]) - int(pattern[0]))
        for p in range(1, length):
            count += abs(int(pattern[p]) - int(pattern[p - 1]))
        return count

    # This function need to be optimized, is used in circular LBP operator
    def bilinear_interpolation(self, face, x, y):
        x1 = int(x)
        x2 = x1 + 1
        y1 = int(y)
        y2 = y1 + 1
        if ((y2 < self.Width) and (x2 < self.Height)):
            P11 = face[x1, y1]
            P12 = face[x1, y2]
            P21 = face[x2, y1]
            P22 = face[x2, y2]
            x = x - x1
            y = y - y1
            pixel = (1 - x) * (1 - y) * P11 + x * (1 - y) * P21 + (1 - x) * y * P12 + x * y * P22
            return int(pixel)
        else:
            return 0

    # Calculate histogram for each image
    def calHistogram(self, ImgLBPope, gradients):
        # All 59 uniform patterns, when P is 8.
        patterns = [0, 1, 2, 3, 4, 6, 7, 8, 12, 14, 15, 16, 24, 28, 30, 31, 32, 48, 56, 60, 62, 63, 64, 96,
                    112, 120, 124, 126, 127, 128, 129, 131, 135, 143, 159, 191, 192, 193, 195, 199, 207,
                    223, 224, 225, 227, 231, 239, 240, 241, 243, 247, 248, 249, 251, 252, 253, 254, 255, 9]
        Img = ImgLBPope.reshape(self.Height, self.Width)  # Height: rows, Width: columns
        gradients = gradients.reshape(self.Height, self.Width)
        Histogram = mat(zeros((self.Patterns,self.region_num)))
        count = 0
        for region in range(self.region_class):
            mask_height, mask_width = int(self.Height / self.h_num[region]), int(self.Width / self.w_num[region])
            # Divide the image into local regions
            if self.overlap_ratio > 0:
                Histogram = mat(zeros((self.Patterns, self.region_w_num * self.region_h_num)))
                count = 0
                for i in range(self.region_h_num):
                    for j in range(self.region_w_num):
                        start_x = i * mask_height - i * self.overlap_size
                        end_x = (i + 1) * mask_height - i * self.overlap_size
                        start_y = j * mask_width - j * self.overlap_size
                        end_y = (j + 1) * mask_width - j * self.overlap_size

                        if (end_x < self.Height and end_y < self.Width):
                            # mask[start_x:end_x, start_y:end_y] = 255
                            x1 = start_x
                            x2 = end_x
                            y1 = start_y
                            y2 = end_y
                        else:
                            if (end_x >= self.Height and end_y < self.Width):
                                x1 = self.Height - mask_height - 1
                                y1 = start_y
                                x2 = self.Height - 1
                                y2 = end_y
                            if (end_x < self.Height and end_y >= self.Width):
                                y1 = self.Width - mask_width - 1
                                x1 = start_x
                                y2 = self.Width - 1
                                x2 = end_x
                            if (end_x >= self.Height and end_y >= self.Width):
                                x1 = self.Height - mask_height - 1
                                x2 = self.Height - 1
                                y1 = self.Width - mask_width - 1
                                y2 = self.Width - 1
                        # hist = cv2.calcHist([array(Img, uint8)], [0], mask, [self.Patterns], [0, 256])
                        hist = [0.0] * self.Patterns
                        for c in range(x1, x2):
                            for r in range(y1, y2):
                                pattern = Img[c, r]
                                for k in range(self.Patterns):
                                    if pattern == patterns[k]:
                                        if self.isgradiented == 1:
                                            hist[k] += gradients[c, r]
                                        else:
                                            hist[k] += 1
                        Histogram[:, count] = mat(hist).flatten().T
                        count += 1

            else:
                for i in range(self.h_num[region]):
                    for j in range(self.w_num[region]):
                        hist = [0.0] * self.Patterns
                        for c in range(i * mask_height, (i + 1) * mask_height):
                            for r in range(j * mask_width, (j + 1) * mask_width):
                                pattern = Img[c, r]
                                for k in range(self.Patterns):
                                    if pattern == patterns[k]:
                                        if self.isgradiented == 1:
                                            hist[k] += gradients[c, r]
                                        else:
                                            hist[k] += 1
            Histogram[:, count] = mat(hist).flatten().T
            count += 1
            # from sklearn.preprocessing import normalize
            # Histogram = mat(normalize(Histogram, axis=0))
            # print(Histogram[0:8,0:8])

        return Histogram.flatten().T

    @fn_timer
    def run_LBP(self, path, para):
        self.parameter = para
        self.Image_Num = len([file for file in os.listdir(path)
                              if os.path.isfile(os.path.join(path, file))])
        self.ids = [0 for i in range(self.Image_Num)]
        self.gradients = mat(zeros((self.Width * self.Height, self.Image_Num)))
        # Load images
        FaceMat = self.loadImages(path).T
        # Calculate LBP opearters for all loaded images
        self.LBPoperator = self.LBP(FaceMat)
        # Calculate histograms
        if self.overlap_ratio > 0:
            self.Histograms = mat(
                zeros((self.Patterns * self.region_w_num * self.region_h_num, shape(self.LBPoperator)[1])))
        else:
            self.Histograms = mat(zeros((self.Patterns * self.region_num, shape(self.LBPoperator)[1])))
        for i in range(shape(self.LBPoperator)[1]):
            Histogram = self.calHistogram(self.LBPoperator[:, i], self.gradients[:, i])
            self.Histograms[:, i] = Histogram

    # recogniseImg: the image needed to be matched
    def recogniseFace(self, recogniseImg, weights, ImgGradient):
        recogniseImg = recogniseImg.T
        ImgLBPope = self.LBP(recogniseImg)
        recogniseHistogram = self.calHistogram(ImgLBPope, ImgGradient)
        minIndex = 0
        minVals = inf
        # Find the most close one, the smallest difference
        for i in range(shape(self.LBPoperator)[1]):
            Histogram = self.Histograms[:, i]
            # Utilize Chi square distance to find the most close match

            if (len(weights) == 0):
                distance = ((array(Histogram - recogniseHistogram) ** 2).sum()) / (
                    (array(Histogram + recogniseHistogram)).sum())
            else:
                if (self.overlap_ratio == 0):
                    regions = self.h_num * self.w_num
                else:
                    regions = self.region_h_num * self.region_w_num
                Histogram = Histogram.reshape(self.Patterns, regions)
                recogniseHistogram = recogniseHistogram.reshape(self.Patterns, regions)
                distance = 0
                for index in range(regions):
                    distance += (((array(Histogram[:, index] - recogniseHistogram[:, index])) ** 2).sum() / (
                        array(Histogram[:, index] + recogniseHistogram[:, index])).sum()) * weights[index]

            if distance < minVals:
                minIndex = i
                minVals = distance
        return minIndex

    # Calculate the recognition rate
    def calculate_Accuracy(self, mypath, weights):
        j = 0
        count = 0
        for m in os.listdir(mypath):
            if (len(m) == 24):
                recogniseImg = cv2.imread(mypath + m, 0)
                ImgGradient = self.cal_Gradient(mat(recogniseImg))
                # recogniseImg = self.gamma_correction(recogniseImg, self.gamma)
                # recogniseImg = cv2.GaussianBlur(recogniseImg, (3, 3), 0)
                # recogniseImg = cv2.equalizeHist(recogniseImg)
                id = int(m[5:7])
                index = self.recogniseFace(mat(recogniseImg).flatten(), weights, ImgGradient)
                if self.ids[index] == id:
                    count = count + 1
                j = j + 1
        if j > 0:
            accuracy = float(count) / j
            return accuracy
        else:
            return 0
